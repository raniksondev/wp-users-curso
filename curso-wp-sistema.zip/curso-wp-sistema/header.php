<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Curso WordPress</title>
	<?php wp_head(); ?>
</head>
<body>
	
