<?php wp_footer(); ?>


<?php get_template_part('_inc/_users/sidebar-alerts'); ?>
</body>
</html>