# wp-users-curso
Tema para o curso para desenvolvedores WordPress
