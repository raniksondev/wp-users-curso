<section class="submenu">
	<ul>
		<li>
			<a href="<?php wp_go('configuracoes/funcoes'); ?>" <?php wp_submenu_active('Funções'); ?>>&bull; Funções</a>
		</li>
		<li>
			<a href="<?php wp_go('configuracoes/permissoes'); ?>" <?php wp_submenu_active('Permissões'); ?>>&bull; Permissões</a>
		</li>
		<li>
			<a href="<?php wp_go('configuracoes/tarefas'); ?>" <?php wp_submenu_active('Tarefas'); ?>>&bull; Tarefas</a>
		</li>
	</ul>
</section>