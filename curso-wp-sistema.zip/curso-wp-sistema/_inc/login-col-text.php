<section class="col-text">
	<section class="text">
		<div class="logo">
			<div class="icon">
				<?php wp_theme_img('check.svg', 60) ?>
			</div>
			<div class="titles">
				<h1>Super<strong>Tasks</strong></h1>
				<p>Gestão de tarefas simples e eficaz.</p>
			</div>
		</div>
	</section>
</section>