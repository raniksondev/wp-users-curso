<section class="modal" id="add-user">
	<div class="ico">
		<span class="icon ion-ios-man"></span>
	</div>
	<section class="header">
		<h4>Cadastrar Usuário</h4>
		<p>Informe os dados do novo usuário.</p>
	</section>
	<section class="body">

		<label>
			<span>Nome</span>
			<input type="text">
		</label>
		<label>
			<span>E-mail</span>
			<input type="text">
		</label>
	</section>
	<section class="footer text-center">
		<button type="button" class="btn-md btn-s" id="btn-send-message">Adicionar</button>
	</section>
</section>