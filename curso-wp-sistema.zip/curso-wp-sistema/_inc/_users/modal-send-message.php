<section class="modal" id="send-message">
	<div class="ico">
		<span class="icon ion-ios-mail-open"></span>
	</div>
	<section class="header">
		<h4>Enviar mensagem</h4>
	</section>
	<section class="body">
		<label>
			<span>Assunto</span>
			<input type="text">
		</label>
		<label>
			<span>Mensagem</span>
			<textarea rows="3"></textarea>
		</label>
	</section>
	<section class="footer text-center">
		<button type="button" class="btn-md btn-s" id="btn-send-message">Enviar Mensagem</button>
	</section>
</section>