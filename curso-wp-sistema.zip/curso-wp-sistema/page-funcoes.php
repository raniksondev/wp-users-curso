<?php get_header(); ?>
<section class="app">
	<?php get_template_part('_inc/app-menu'); ?>
	<?php get_template_part('_inc/_configuracoes/submenu'); ?>
	<section class="content">

		
	</section>
</section>
<?php get_footer(); ?>
